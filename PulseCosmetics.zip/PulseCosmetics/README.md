# Pulse Cosmetics (Fabric, Minecraft 1.21.11)

Крылья, плащи, маски со смайликами и перчатки с собственным меню. Косметика видна только тебе.
Клавиша **K** открывает меню (меняется в управлении, категория "Pulse Cosmetics").
Выбор хранится в `config/pulsecosmetics.properties`.

Крылья: Фиолетовые, Зелёные, Ангельские зелёные, Ангельские фиолетовые (слегка машут).
Перчатки: Чёрные, Белые, Фиолетовые, Зелёные.
Плащи: Багровый, Океан, Аврора, Pulse.
Маски: Они, Медицинская, Визор + смайлики (Улыбка, Крутой, Злой, Смех, Влюблённый, Подмигивание).

## Как получить .jar
**Вариант 1 (без установки ничего):** залей папку проекта в свой репозиторий на GitHub.
Вкладка Actions -> Build Pulse Cosmetics -> Artifacts -> pulse-cosmetics (внутри готовый jar).

**Вариант 2 (локально):** нужна JDK 21. Сгенерируй шаблон на https://fabricmc.net/develop (1.21.11, Yarn),
скопируй в него папку `src/` отсюда и выполни `gradlew build`. Jar будет в `build/libs/`.

Готовый jar положи в `mods/` рядом с Pulse (нужен Fabric API).

Версии в `gradle.properties` указаны по памяти, при ошибке сверь их с fabricmc.net/develop.

## Добавить свою косметику
- Плащ: PNG 64x32 (формат ванильного плаща) -> `textures/cape/имя.png` и `cape("имя", "Название");` в `Cosmetics.java`.
- Смайлик: PNG 64x32, лицо рисуется в области (1,1)-(9,9) -> `textures/mask/имя.png` и `emoji("имя", "Название");`.
- Своя маска из кубов: `mask("имя", "Название", new Box(...), ...)`. Прозрачные пиксели вырезаются.

Крылья: PNG 128x32 (правое крыло в (1,1) 20x24, левое в (43,1)), строка `wings("имя", "Название");`.
Перчатки: PNG 64x32, строка `gloves("имя", "Название");`.

## Если сборка падает
Код рендера (`CosmeticsLayer`) использует API 1.21.11, которое сильно менялось. Вероятные места:
- `RenderLayer.getEntityCutoutNoCull` -> может быть `RenderLayers.entityCutoutNoCull` (метод `layer`).
- `queue.submitCustom(...)` и интерфейс `Custom` у `OrderedRenderCommandQueue`.
- `state.x/y/z`, `state.invisible`, `state.age` у `PlayerEntityRenderState`.
- `model.rightArm` / `model.leftArm` в `PlayerEntityModel` (перчатки рассчитаны на руки шириной 4, для slim-скина торчат на пиксель).
