package dev.cosmetics;

import java.util.List;
import net.minecraft.util.Identifier;

/** Одна косметика: слот, текстура, размер текстуры и набор частей (кубов с привязкой к телу). */
public record CosmeticDef(String id, String name, Slot slot, Identifier texture,
                          int texW, int texH, List<Part> parts) {

    public enum Slot { CAPE, WINGS, MASK, GLOVES }

    /** К какой части модели игрока крепится куб. */
    public enum Attach { HEAD, BODY, RIGHT_ARM, LEFT_ARM }

    /**
     * Куб в пикселях модели (1 блок = 16 пикселей): x,y,z - угол, w,h,d - размер,
     * inflate - раздувание, u,v - смещение в текстуре (развёртка как у ванильных кубов).
     */
    public record Box(float x, float y, float z, int w, int h, int d, float inflate, int u, int v) {}

    /**
     * Куб + привязка: сдвиг (tx,ty,tz в пикселях), поворот (rx,ry,rz в градусах),
     * swing - амплитуда покачивания по Y в градусах (для взмахов крыльев).
     */
    public record Part(Attach attach, float tx, float ty, float tz,
                       float rx, float ry, float rz, float swing, Box box) {
        public Part(Attach attach, Box box) {
            this(attach, 0, 0, 0, 0, 0, 0, 0, box);
        }
    }
}
