package dev.cosmetics;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Identifier;

import dev.cosmetics.CosmeticDef.Attach;
import dev.cosmetics.CosmeticDef.Box;
import dev.cosmetics.CosmeticDef.Part;
import dev.cosmetics.CosmeticDef.Slot;

/** Реестр косметики. Новую добавляй строкой ниже + PNG в textures/. */
public final class Cosmetics {
    public static final List<CosmeticDef> ALL = new ArrayList<>();

    static {
        // Крылья (текстура 128x32: правое и левое крыло рядом)
        wings("purple", "Фиолетовые");
        wings("green", "Зелёные");
        wings("angel_green", "Ангельские зелёные");
        wings("angel_purple", "Ангельские фиолетовые");

        // Плащи (текстура 64x32, формат ванильного плаща)
        cape("crimson", "Багровый");
        cape("ocean", "Океан");
        cape("aurora", "Аврора");
        cape("pulse", "Pulse");

        // Маски (голова: x -4..4, y -8..0, z -4..4, перед = -Z)
        mask("oni", "Они",
                new Box(-4, -8, -5, 8, 8, 1, 0.25f, 0, 0),
                new Box(-4, -11, -4, 1, 3, 1, 0f, 32, 0),
                new Box(3, -11, -4, 1, 3, 1, 0f, 40, 0));
        mask("medic", "Медицинская", new Box(-4, -3, -5, 8, 3, 1, 0.2f, 0, 0));
        mask("visor", "Визор", new Box(-4, -5, -5, 8, 2, 1, 0.3f, 0, 0));
        emoji("smile", "Улыбка");
        emoji("cool", "Крутой");
        emoji("angry", "Злой");
        emoji("laugh", "Смех");
        emoji("love", "Влюблённый");
        emoji("wink", "Подмигивание");

        // Перчатки
        gloves("black", "Чёрные");
        gloves("white", "Белые");
        gloves("purple", "Фиолетовые");
        gloves("green", "Зелёные");
    }

    private Cosmetics() {}

    private static Identifier tex(String path) {
        return Identifier.of(CosmeticsMod.ID, "textures/" + path + ".png");
    }

    private static void cape(String key, String name) {
        Part p = new Part(Attach.BODY, 0, 0, 2.02f, 6f, 180f, 0f, 0f, new Box(-5, 0, -1, 10, 16, 1, 0f, 0, 0));
        ALL.add(new CosmeticDef("cape_" + key, name, Slot.CAPE, tex("cape/" + key), 64, 32, List.of(p)));
    }

    /** Два плоских крыла (20x24 пикселя), закреплены у лопаток и развёрнуты назад-наружу, слегка машут. */
    private static void wings(String key, String name) {
        Box right = new Box(0, -7, 0, 20, 24, 1, 0f, 0, 0);
        Box left = new Box(-20, -7, 0, 20, 24, 1, 0f, 42, 0);
        ALL.add(new CosmeticDef("wings_" + key, name, Slot.WINGS, tex("wings/" + key), 128, 32, List.of(
                new Part(Attach.BODY, -1.5f, 0, 2.3f, 0, 210f, 0, 5f, right),
                new Part(Attach.BODY, 1.5f, 0, 2.3f, 0, 150f, 0, -5f, left))));
    }

    private static void emoji(String key, String name) {
        mask(key, name, new Box(-4, -8, -5, 8, 8, 1, 0.25f, 0, 0));
    }

    private static void mask(String key, String name, Box... boxes) {
        List<Part> parts = new ArrayList<>();
        for (Box b : boxes) parts.add(new Part(Attach.HEAD, b));
        ALL.add(new CosmeticDef("mask_" + key, name, Slot.MASK, tex("mask/" + key), 64, 32, parts));
    }

    /** Перчатки на обеих руках (нижние 5 пикселей руки). */
    private static void gloves(String key, String name) {
        ALL.add(new CosmeticDef("gloves_" + key, name, Slot.GLOVES, tex("gloves/" + key), 64, 32, List.of(
                new Part(Attach.RIGHT_ARM, new Box(-3, 5, -2, 4, 5, 4, 0.3f, 0, 0)),
                new Part(Attach.LEFT_ARM, new Box(-1, 5, -2, 4, 5, 4, 0.3f, 0, 0)))));
    }

    public static CosmeticDef find(String id) {
        if (id == null || id.isEmpty()) return null;
        for (CosmeticDef d : ALL) if (d.id().equals(id)) return d;
        return null;
    }

    public static List<CosmeticDef> list(Slot slot) {
        List<CosmeticDef> out = new ArrayList<>();
        for (CosmeticDef d : ALL) if (d.slot() == slot) out.add(d);
        return out;
    }
}
