package dev.cosmetics;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.loader.api.FabricLoader;

import dev.cosmetics.CosmeticDef.Slot;

/** Хранит выбранную косметику по слотам в config/pulsecosmetics.properties. */
public final class CosmeticsConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pulsecosmetics.properties");
    private static final Map<Slot, String> SELECTED = new ConcurrentHashMap<>();

    private CosmeticsConfig() {}

    public static String get(Slot slot) {
        return SELECTED.getOrDefault(slot, "");
    }

    public static void set(Slot slot, String id) {
        SELECTED.put(slot, id == null ? "" : id);
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (var in = Files.newInputStream(FILE)) {
            Properties p = new Properties();
            p.load(in);
            for (Slot s : Slot.values()) set(s, p.getProperty(s.name().toLowerCase(), ""));
        } catch (IOException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Slot s : Slot.values()) p.setProperty(s.name().toLowerCase(), get(s));
        try (OutputStream out = Files.newOutputStream(FILE)) {
            p.store(out, "Pulse Cosmetics");
        } catch (IOException ignored) {
        }
    }
}
