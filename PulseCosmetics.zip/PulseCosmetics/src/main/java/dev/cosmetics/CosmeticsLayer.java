package dev.cosmetics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.OrderedRenderCommandQueue;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

import dev.cosmetics.CosmeticDef.Attach;
import dev.cosmetics.CosmeticDef.Box;
import dev.cosmetics.CosmeticDef.Part;
import dev.cosmetics.CosmeticDef.Slot;

/** Рисует выбранную косметику (крылья, плащ, маска, перчатки) на локальном игроке. */
public class CosmeticsLayer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {

    public CosmeticsLayer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                       PlayerEntityRenderState state, float limbAngle, float limbDistance) {
        if (state.invisible || !isLocalPlayer(state)) return;

        PlayerEntityModel model = getContextModel();

        for (Slot slot : Slot.values()) {
            CosmeticDef def = Cosmetics.find(CosmeticsConfig.get(slot));
            if (def == null) continue;

            for (Part part : def.parts()) {
                matrices.push();
                partOf(model, part.attach()).rotate(matrices);
                matrices.translate(part.tx() / 16f, part.ty() / 16f, part.tz() / 16f);

                float ry = part.ry();
                if (part.swing() != 0f) ry += part.swing() * (float) Math.sin(state.age * 0.15f);
                if (part.rx() != 0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(part.rx()));
                if (ry != 0f) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
                if (part.rz() != 0f) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(part.rz()));

                Box box = part.box();
                queue.submitCustom(matrices, layer(def.texture()),
                        (entry, vc) -> drawBox(vc, entry, box, def.texW(), def.texH(), light));
                matrices.pop();
            }
        }
    }

    private static ModelPart partOf(PlayerEntityModel model, Attach attach) {
        return switch (attach) {
            case HEAD -> model.head;
            case BODY -> model.body;
            case RIGHT_ARM -> model.rightArm;
            case LEFT_ARM -> model.leftArm;
        };
    }

    private static boolean isLocalPlayer(PlayerEntityRenderState state) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) return false;
        double dx = state.x - p.getX(), dy = state.y - p.getY(), dz = state.z - p.getZ();
        return dx * dx + dy * dy + dz * dz < 0.25;
    }

    /** Если не компилируется - здесь меняется на RenderLayers.entityCutoutNoCull(id). */
    private static RenderLayer layer(Identifier texture) {
        return RenderLayer.getEntityCutoutNoCull(texture);
    }

    // ---------- геометрия ----------

    private static void drawBox(VertexConsumer vc, MatrixStack.Entry e, Box b, int tw, int th, int light) {
        float inf = b.inflate();
        float x0 = (b.x() - inf) / 16f, x1 = (b.x() + b.w() + inf) / 16f;
        float y0 = (b.y() - inf) / 16f, y1 = (b.y() + b.h() + inf) / 16f;
        float z0 = (b.z() - inf) / 16f, z1 = (b.z() + b.d() + inf) / 16f;
        int u = b.u(), v = b.v(), w = b.w(), h = b.h(), d = b.d();

        // перед (-Z)
        quad(vc, e, light, tw, th, 0, 0, -1,
                p(x0, y0, z0, u + d, v + d), p(x1, y0, z0, u + d + w, v + d),
                p(x1, y1, z0, u + d + w, v + d + h), p(x0, y1, z0, u + d, v + d + h));
        // зад (+Z)
        quad(vc, e, light, tw, th, 0, 0, 1,
                p(x1, y0, z1, u + 2 * d + w, v + d), p(x0, y0, z1, u + 2 * d + 2 * w, v + d),
                p(x0, y1, z1, u + 2 * d + 2 * w, v + d + h), p(x1, y1, z1, u + 2 * d + w, v + d + h));
        // правый бок (-X)
        quad(vc, e, light, tw, th, -1, 0, 0,
                p(x0, y0, z1, u, v + d), p(x0, y0, z0, u + d, v + d),
                p(x0, y1, z0, u + d, v + d + h), p(x0, y1, z1, u, v + d + h));
        // левый бок (+X)
        quad(vc, e, light, tw, th, 1, 0, 0,
                p(x1, y0, z0, u + d + w, v + d), p(x1, y0, z1, u + 2 * d + w, v + d),
                p(x1, y1, z1, u + 2 * d + w, v + d + h), p(x1, y1, z0, u + d + w, v + d + h));
        // верх (-Y)
        quad(vc, e, light, tw, th, 0, -1, 0,
                p(x0, y0, z1, u + d, v), p(x1, y0, z1, u + d + w, v),
                p(x1, y0, z0, u + d + w, v + d), p(x0, y0, z0, u + d, v + d));
        // низ (+Y)
        quad(vc, e, light, tw, th, 0, 1, 0,
                p(x0, y1, z0, u + d + w, v), p(x1, y1, z0, u + d + 2 * w, v),
                p(x1, y1, z1, u + d + 2 * w, v + d), p(x0, y1, z1, u + d + w, v + d));
    }

    private static float[] p(float x, float y, float z, float u, float v) {
        return new float[]{x, y, z, u, v};
    }

    private static void quad(VertexConsumer vc, MatrixStack.Entry e, int light, int tw, int th,
                             float nx, float ny, float nz, float[]... pts) {
        for (float[] q : pts) {
            vc.vertex(e, q[0], q[1], q[2])
                    .color(0xFFFFFFFF)
                    .texture(q[3] / tw, q[4] / th)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(e, nx, ny, nz);
        }
    }
}
