package dev.cosmetics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class CosmeticsMod implements ClientModInitializer {
    public static final String ID = "pulsecosmetics";

    @Override
    public void onInitializeClient() {
        CosmeticsConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(ID, "main"));
        KeyBinding open = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsecosmetics.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new CosmeticsScreen(null));
            }
        });

        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (renderer instanceof PlayerEntityRenderer pr) helper.register(new CosmeticsLayer(pr));
        });
    }
}
