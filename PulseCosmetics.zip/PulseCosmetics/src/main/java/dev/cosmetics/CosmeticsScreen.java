package dev.cosmetics;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import dev.cosmetics.CosmeticDef.Slot;

/** Меню Pulse Cosmetics: вкладки Крылья / Плащи / Маски / Перчатки и сетка выбора. */
public class CosmeticsScreen extends Screen {
    private static final int ACCENT = 0xFF00D4EB;
    private static final int COLS = 3, CELL_W = 104, CELL_H = 20, GAP = 4;
    private static final int GRID_W = COLS * CELL_W + (COLS - 1) * GAP;

    private static final Slot[] TABS = {Slot.WINGS, Slot.CAPE, Slot.MASK, Slot.GLOVES};
    private static final String[] TAB_NAMES = {"Крылья", "Плащи", "Маски", "Перчатки"};

    private static Slot tab = Slot.WINGS;   // вкладка запоминается между открытиями

    private final Screen parent;

    public CosmeticsScreen(Screen parent) {
        super(Text.literal("Pulse Cosmetics"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = width / 2 - GRID_W / 2;

        // вкладки
        int tabW = (GRID_W - GAP * (TABS.length - 1)) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            Slot slot = TABS[i];
            String label = tab == slot ? "[ " + TAB_NAMES[i] + " ]" : TAB_NAMES[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                tab = slot;
                clearAndInit();
            }).dimensions(left + i * (tabW + GAP), 36, tabW, 20).build());
        }

        // сетка выбора
        String current = CosmeticsConfig.get(tab);
        List<String[]> items = new ArrayList<>();      // {id, название}
        items.add(new String[]{"", "Нет"});
        for (CosmeticDef d : Cosmetics.list(tab)) items.add(new String[]{d.id(), d.name()});

        for (int i = 0; i < items.size(); i++) {
            String id = items.get(i)[0], name = items.get(i)[1];
            int x = left + (i % COLS) * (CELL_W + GAP);
            int y = 66 + (i / COLS) * (CELL_H + GAP);
            boolean selected = id.equals(current);
            addDrawableChild(ButtonWidget.builder(Text.literal(selected ? "> " + name + " <" : name),
                    b -> select(id)).dimensions(x, y, CELL_W, CELL_H).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> close())
                .dimensions(width / 2 - 60, height - 32, 120, 20).build());
    }

    private void select(String id) {
        CosmeticsConfig.set(tab, id);
        CosmeticsConfig.save();
        clearAndInit();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int x0 = width / 2 - GRID_W / 2 - 12, x1 = width / 2 + GRID_W / 2 + 12;
        int y0 = 14, y1 = height - 40;
        ctx.fill(x0, y0, x1, y1, 0xC0101018);
        ctx.fill(x0, y0, x1, y0 + 1, ACCENT);
        ctx.fill(x0, y1 - 1, x1, y1, 0xFF2A2A3A);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, ACCENT);
        CosmeticDef d = Cosmetics.find(CosmeticsConfig.get(tab));
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Выбрано: " + (d == null ? "нет" : d.name())), width / 2, height - 54, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
